# InsightFlow pipeline

    cd insightflow && python -m venv .venv && source .venv/bin/activate
    pip install -r pipeline/requirements.txt && cp .env.example .env   # fill keys
    python pipeline/01_dedupe.py          # 7000 rows -> unique texts + counts
    python pipeline/02_adaption.py        # upload + cost ESTIMATE (no spend)
    python pipeline/02_adaption.py --go   # real Adaption run
    # save Adaption's output as data/adapted.csv (cols: id, review, adapted_text, count, category)
    python pipeline/03_analyze.py         # -> data/analysis.json (the app's seed data)
